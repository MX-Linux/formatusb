<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="hi">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <source>Program_Name</source>
        <translation>प्रोग्राम नाम (_N)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="39"/>
        <source>Show all devices</source>
        <translation>सभी उपकरण दिखाएँ</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="46"/>
        <source>Format</source>
        <translation>प्रारूप</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="54"/>
        <source>Defaults</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="59"/>
        <source>msdos</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="64"/>
        <source>gpt</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="72"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Target USB Device&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;लक्षित यूएसबी उपकरण चयन&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="82"/>
        <source>Show partitions</source>
        <translation>विभाजन दिखाएँ</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="138"/>
        <source>Refresh drive list</source>
        <translation>ड्राइव सूची रिफ्रेश करें</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="152"/>
        <source>USB-DATA</source>
        <translation>यूएसबी-डेटा</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="159"/>
        <source>File System Label</source>
        <translation>फाइल सिस्टम उपनाम</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="166"/>
        <source>Partition Table Type</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="225"/>
        <source>Quit application</source>
        <translation>अनुप्रयोग बंद करें</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="228"/>
        <source>Close</source>
        <translation>बंद करें</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="235"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="273"/>
        <source>Display help </source>
        <translation>सहायता देखें</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="276"/>
        <source>Help</source>
        <translation>सहायता</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="283"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="315"/>
        <source>About this application</source>
        <translation>इस अनुप्रयोग के बारे में</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="318"/>
        <source>About...</source>
        <translation>बारे में...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="325"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="357"/>
        <source>Next</source>
        <translation>अगला</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="383"/>
        <source>Back</source>
        <translation>पिछला</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="184"/>
        <source>Success</source>
        <translation>सफल</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="184"/>
        <source>Format successful!</source>
        <translation>फॉर्मेट करना सफल!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="186"/>
        <location filename="../mainwindow.cpp" line="315"/>
        <source>Failure</source>
        <translation>विफल</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="186"/>
        <source>Error encountered in the Format process</source>
        <translation>फॉर्मेट प्रक्रिया हेतु त्रुटि</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="217"/>
        <source>Error</source>
        <translation>त्रुटि</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="217"/>
        <source>Please select a USB device to write to</source>
        <translation>राइट हेतु यूएसबी उपकरण चुनें</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="222"/>
        <source>These actions will destroy all data on 

</source>
        <translation>इन कार्यों से इस पर मौजूद सारा डेटा नष्ट हो जाएगा

</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="222"/>
        <source>Do you wish to continue?</source>
        <translation>क्या आप जारी रखना चाहते हैं?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="258"/>
        <source>About %1</source>
        <translation>%1 के बारे में</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="259"/>
        <source>Version: </source>
        <translation>संस्करण :</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="260"/>
        <source>Program for formatting USB devices</source>
        <translation>यूएसबी उपकरण फॉर्मेट करने हेतु प्रोग्राम</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="262"/>
        <source>Copyright (c) MX Linux</source>
        <translation>कॉपीराइट (c) एमएक्स लिनक्स</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <source>%1 License</source>
        <translation>%1 लाइसेंस</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="271"/>
        <source>%1 Help</source>
        <translation>%1 सहायता</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="315"/>
        <source>Invalid Name</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="34"/>
        <source>License</source>
        <translation>लाइसेंस</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="35"/>
        <location filename="../about.cpp" line="45"/>
        <source>Changelog</source>
        <translation>बदलाव सूची</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="36"/>
        <source>Cancel</source>
        <translation>रद्द करें</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="53"/>
        <source>&amp;Close</source>
        <translation>बंद करें (&amp;C)</translation>
    </message>
</context>
</TS>