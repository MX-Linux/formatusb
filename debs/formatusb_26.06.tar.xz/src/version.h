inline const QString VERSION {"26.06"};
