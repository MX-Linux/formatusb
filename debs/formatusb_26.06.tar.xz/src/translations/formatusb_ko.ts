<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ko">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <source>Program_Name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="39"/>
        <source>Show all devices</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="46"/>
        <source>Format</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="54"/>
        <source>Defaults</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="59"/>
        <source>msdos</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="64"/>
        <source>gpt</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="72"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Target USB Device&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="82"/>
        <source>Show partitions</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="138"/>
        <source>Refresh drive list</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="152"/>
        <source>USB-DATA</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="159"/>
        <source>File System Label</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="166"/>
        <source>Partition Table Type</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="225"/>
        <source>Quit application</source>
        <translation>종료</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="228"/>
        <source>Close</source>
        <translation>닫기</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="235"/>
        <source>Alt+N</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="273"/>
        <source>Display help </source>
        <translation>도움말 표시</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="276"/>
        <source>Help</source>
        <translation>도움말</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="283"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="315"/>
        <source>About this application</source>
        <translation>이 애플리케이션 정보</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="318"/>
        <source>About...</source>
        <translation>About...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="325"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="357"/>
        <source>Next</source>
        <translation>다음으로</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="383"/>
        <source>Back</source>
        <translation>뒤로</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="184"/>
        <source>Success</source>
        <translation>성공</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="184"/>
        <source>Format successful!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="186"/>
        <location filename="../mainwindow.cpp" line="315"/>
        <source>Failure</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="186"/>
        <source>Error encountered in the Format process</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="217"/>
        <source>Error</source>
        <translation>에러</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="217"/>
        <source>Please select a USB device to write to</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="222"/>
        <source>These actions will destroy all data on 

</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="222"/>
        <source>Do you wish to continue?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="258"/>
        <source>About %1</source>
        <translation>%1 정보</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="259"/>
        <source>Version: </source>
        <translation>버전:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="260"/>
        <source>Program for formatting USB devices</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="262"/>
        <source>Copyright (c) MX Linux</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <source>%1 License</source>
        <translation>%1 라이센스</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="271"/>
        <source>%1 Help</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="315"/>
        <source>Invalid Name</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="34"/>
        <source>License</source>
        <translation>라이센스</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="35"/>
        <location filename="../about.cpp" line="45"/>
        <source>Changelog</source>
        <translation>변경 로그</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="36"/>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="53"/>
        <source>&amp;Close</source>
        <translation>닫기(&amp;C)</translation>
    </message>
</context>
</TS>