<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sk">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <source>Program_Name</source>
        <translation>Vytvoriť LiveUSB</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="39"/>
        <source>Show all devices</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="46"/>
        <source>Format</source>
        <translation>Formát zobrazenia</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="54"/>
        <source>Defaults</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="59"/>
        <source>msdos</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="64"/>
        <source>gpt</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="72"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Target USB Device&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Vyberte cieľovú USB Jednotku&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="82"/>
        <source>Show partitions</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="138"/>
        <source>Refresh drive list</source>
        <translation>Obnoviť zoznam diskových jednotiek</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="152"/>
        <source>USB-DATA</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="159"/>
        <source>File System Label</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="166"/>
        <source>Partition Table Type</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="225"/>
        <source>Quit application</source>
        <translation>Zatvoriť aplikáciu</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="228"/>
        <source>Close</source>
        <translation>Zavrieť</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="235"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="273"/>
        <source>Display help </source>
        <translation>Zobraziť nápovedu</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="276"/>
        <source>Help</source>
        <translation>Pomoc</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="283"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="315"/>
        <source>About this application</source>
        <translation>O tejto aplikácii</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="318"/>
        <source>About...</source>
        <translation>O Programe</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="325"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="357"/>
        <source>Next</source>
        <translation>Nasledujúce</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="383"/>
        <source>Back</source>
        <translation>Späť</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="184"/>
        <source>Success</source>
        <translation>Úspech</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="184"/>
        <source>Format successful!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="186"/>
        <location filename="../mainwindow.cpp" line="315"/>
        <source>Failure</source>
        <translation>Neúspech</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="186"/>
        <source>Error encountered in the Format process</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="217"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="217"/>
        <source>Please select a USB device to write to</source>
        <translation>Prosím vyberte USB jednotku k zápisu</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="222"/>
        <source>These actions will destroy all data on 

</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="222"/>
        <source>Do you wish to continue?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="258"/>
        <source>About %1</source>
        <translation>Okolo %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="259"/>
        <source>Version: </source>
        <translation>Verzia:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="260"/>
        <source>Program for formatting USB devices</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="262"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <source>%1 License</source>
        <translation>%1 Licencia</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="271"/>
        <source>%1 Help</source>
        <translation>%1 Pomoc</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="315"/>
        <source>Invalid Name</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="34"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="35"/>
        <location filename="../about.cpp" line="45"/>
        <source>Changelog</source>
        <translation>História zmien</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="36"/>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="53"/>
        <source>&amp;Close</source>
        <translation>&amp;Zatvoriť</translation>
    </message>
</context>
</TS>