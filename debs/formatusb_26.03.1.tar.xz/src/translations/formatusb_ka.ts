<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ka">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <source>Program_Name</source>
        <translation>პროგრამის_სახელი</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="39"/>
        <source>Show all devices</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="46"/>
        <source>Format</source>
        <translation>ფორმატი</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="54"/>
        <source>Defaults</source>
        <translation>ნაგულისხმევები</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="59"/>
        <source>msdos</source>
        <translation>msdos</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="64"/>
        <source>gpt</source>
        <translation>gpt</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="72"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Target USB Device&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="82"/>
        <source>Show partitions</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="138"/>
        <source>Refresh drive list</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="152"/>
        <source>USB-DATA</source>
        <translation>USB-DATA</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="159"/>
        <source>File System Label</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="166"/>
        <source>Partition Table Type</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="225"/>
        <source>Quit application</source>
        <translation>აპლიკაციიდან გასვლა</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="228"/>
        <source>Close</source>
        <translation>დახურვა</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="235"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="273"/>
        <source>Display help </source>
        <translation>დახმარების ჩვენება </translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="276"/>
        <source>Help</source>
        <translation>დახმარება</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="283"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="315"/>
        <source>About this application</source>
        <translation>ამ აპლიკაციის შესახებ</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="318"/>
        <source>About...</source>
        <translation>შესახებ...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="325"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="357"/>
        <source>Next</source>
        <translation>შემდეგი</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="383"/>
        <source>Back</source>
        <translation>უკან</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="184"/>
        <source>Success</source>
        <translation>წარმატება</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="184"/>
        <source>Format successful!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="186"/>
        <location filename="../mainwindow.cpp" line="315"/>
        <source>Failure</source>
        <translation>ჩავარდნა</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="186"/>
        <source>Error encountered in the Format process</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="217"/>
        <source>Error</source>
        <translation>შეცდომა</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="217"/>
        <source>Please select a USB device to write to</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="222"/>
        <source>These actions will destroy all data on 

</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="222"/>
        <source>Do you wish to continue?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="258"/>
        <source>About %1</source>
        <translation>%1-ის შესახებ</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="259"/>
        <source>Version: </source>
        <translation>ვერსია:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="260"/>
        <source>Program for formatting USB devices</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="262"/>
        <source>Copyright (c) MX Linux</source>
        <translation>(c) MX Linux საავტორო ფულებები დაცულია</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <source>%1 License</source>
        <translation>ლიცენზია %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="271"/>
        <source>%1 Help</source>
        <translation>%1-ის დახმარება</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="315"/>
        <source>Invalid Name</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="34"/>
        <source>License</source>
        <translation>ლიცენზია</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="35"/>
        <location filename="../about.cpp" line="45"/>
        <source>Changelog</source>
        <translation>ცვლილებების ჟურნალი</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="36"/>
        <source>Cancel</source>
        <translation>გაუქმება</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="53"/>
        <source>&amp;Close</source>
        <translation>&amp;დახურვა</translation>
    </message>
</context>
</TS>